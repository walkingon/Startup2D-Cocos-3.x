import { instantiate } from 'cc';
import { EventHandler } from 'cc';
import { Button } from 'cc';
import { Label } from 'cc';
import { _decorator, Component, Node } from 'cc';
const { ccclass, property } = _decorator;

/**选择器中的选项 */
export interface ISelecterItem {
    /**显示名称 */
    label: string;
    /**实际传递的值 */
    value: any;
}

@ccclass('Selecter')
export class Selecter extends Component {
    @property(Label)
    private label: Label;

    @property(Node)
    private origin: Node;

    /**展开状态 */
    private isOpen: boolean = false;
    private onchange: (value: any) => void;
    private items: ISelecterItem[] = [];

    public init(list: ISelecterItem[], defaultIndex: number, onChange: (value: any) => void){
        this.items = list;
        this.label.string = list[defaultIndex].label;
        for(let i = 0; i < list.length; i++){
            const nd = instantiate(this.origin);
            nd.name = `item-${i}`;
            nd.setParent(this.origin.parent)
            const lb = nd.getChildByName('Label').getComponent(Label);
            lb.string = list[i].label;

            const btn = nd.getComponent(Button);
            const event = new EventHandler();
            event.target = this.node;
            event.component = "Selecter";
            event.handler = "onSelect";
            event.customEventData = list[i].value;
            btn.clickEvents.push(event);
        }
        this.onchange = onChange;
    }

    private onSelect(et, value){
        if(this.isOpen){
            this.close();
        }
        this.items.forEach((item, index)=>{
            if(item.value == value){
                this.label.string = item.label;
                return;
            }
        })
        this.onchange(value);
    }

    private onClick() {
        if(this.isOpen){
            this.close();
        }else{
            this.open();
        }
    }

    /**展开 */
    private open() {
        const children = this.origin.parent.children;
        children.forEach((child, index) =>{
            if(child.name !== 'origin'){
                child.active = true;
            }
        })
        this.isOpen = true;
    }

    /**收起 */
    private close() {
        const children = this.origin.parent.children;
        children.forEach((child, index) =>{
            if(child.name !== 'origin'){
                child.active = false;
            }
        })
        this.isOpen = false;
    }
}


